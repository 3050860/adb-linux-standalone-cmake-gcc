#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "libadb::adb" for configuration "None"
set_property(TARGET libadb::adb APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(libadb::adb PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libadb.so.1.0.0"
  IMPORTED_SONAME_NONE "libadb.so.1"
  )

list(APPEND _cmake_import_check_targets libadb::adb )
list(APPEND _cmake_import_check_files_for_libadb::adb "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libadb.so.1.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

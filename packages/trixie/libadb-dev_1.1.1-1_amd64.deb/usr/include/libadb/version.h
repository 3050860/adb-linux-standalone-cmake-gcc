/*
 * libadb — версия библиотеки (файл генерируется CMake из version.h.in).
 * Не редактировать вручную.
 */
#pragma once

#define LIBADB_VERSION_MAJOR  1
#define LIBADB_VERSION_MINOR  1
#define LIBADB_VERSION_PATCH  1
#define LIBADB_VERSION_STRING "1.1.1"

/* major<<16 | minor<<8 | patch */
#define LIBADB_VERSION_NUMBER                                                  \
    (((1) << 16) | ((1) << 8) |    \
     (1))
